﻿using System;
using System.Collections.Generic;
using System.Text;

public class Backpack : Bag
{

    public Backpack()
        :base(100)
    {

    }
}

