﻿using System;
using System.Collections.Generic;
using System.Text;


public class PoisonPotion : Item
{
    public PoisonPotion(int weight) : base(5)
    {
    }

    public override void AffectCharacter(Character character)
    {
        base.AffectCharacter(character);
        character.DecreaseHealth(20);
    }
}

